import UIKit


func multiplyTwoNum(num1: Int, num2: Int) -> Int {
return num1 * num2
}

var multiplyanumber: ( Int, Int) -> Int = { (num1, num2) in
    return num1 * num2 }
print(multiplyanumber(72, 68))
//Used for multiplying Doubles
//func multiply( num1: Double, num2: Double) -> Double{
    //return num1 * num2
//}
//var product = multiply(num1: e,  num2: f)

